<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group([
	// 'namespace' => ''
], function() {

	Route::get('/temp', [
		'as' => 'temp.route',
		'uses' => 'StudentController@getStudents'
	]);

});

Route::domain('{account}.myapp.com')->group(function () {
    Route::get('demo', function ($account) {
        dd($account);
    });

    Route::get('add-student', [
    	'as' => 'student.read.add_support_data',
		'uses' => 'StudentController@addSupportData'
    ]);

    Route::post('get-student', [
    	'as' => 'student.write.add.process',
		'uses' => 'StudentController@addStudent'
    ]);
});