<!DOCTYPE html>
<html>
<head>
	<!-- <meta name="_token" content="{{ csrf_token() }}"> -->
	<title></title>
</head>
<body>
	<?php
		$urlParts = explode('.', $_SERVER['HTTP_HOST']);
		$sudomain=$urlParts[0];
	?>
	<form action="<?= route('student.write.add.process', [$sudomain]) ?>" method="POST">
		@csrf
		<!-- <input type="hidden" name="_token" value="{{ csrf_token() }}"> -->
		<input type="text" name="name" placeholder="Name"><br>
		<input type="text" name="address" placeholder="Address"><br>
		<input type="text" name="city" placeholder="City"><br>
		<button type="submit">Submit</button>		
	</form>


</body>
</html>