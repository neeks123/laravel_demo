<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class StudentController {

	public function getStudents()
	{
		dd('nikhil');
	}

	public function addSupportData()
	{
		return view('add-student');
	}

	public function addStudent(Request $request)
	{
	//dd($request->all());

	$name = $request->input('name');
	$address = $request->input('address');
	$city = $request->input('city');
	$created_at = date('Y-m-d H:i:s');

	$data=array('name'=>$name,"address"=>$address,"city"=>$city,"created_at"=>$created_at);
	DB::table('students')->insert($data);

	echo "Record inserted successfully.<br/>";
	echo '<a href = "/add-student">Click Here</a> to go back.';

	}

}