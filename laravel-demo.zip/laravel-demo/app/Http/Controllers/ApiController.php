<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;

class ApiController extends Controller
{
	/*insert student record*/

    public function create(Request $request){
    	$students= new Student();
    	$students->name=$request->input('name');
    	$students->address=$request->input('address');
    	$students->city=$request->input('city');
    	$students->created_at=date('Y-m-d H:i:s');

    	$students->save();
    	return response()->json($students);
    }
}
